#ifndef __gpio_module_H__
#define __gpio_module_H__

#define INPUT_FUCTION 0
#define OUTPUT_FUCTION 1

int write_gpio(int gpio, int value);
int read_gpio(int gpio);





#endif