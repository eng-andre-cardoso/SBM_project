#include "gpio_module.h"

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/time.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>



//-------------------------------------------------
#define PATH "/dev/raspiGpio"


//-------------------------------------------------
    int write_gpio(int gpio, int value){
        char string[10];
        char val;
        
        if(value != 0 && value != 1){
            return 0;// colocar ERRO
        }
        sprintf(string,"%s%d", PATH, gpio);
        int fd = open(string,O_RDWR);

        if(fd < 0){
		printf("\nFailed to open %s /dev/buttonarroz: %s\n\n", string, strerror(errno));	//error handling
		return 0; //colocar erro
	    }

        else 
        printf("\n/dev/raspiGpio%d Opened! value :%d \n",gpio, value);//success
        
        if(value == 1){
         write(fd, "1", 1);
        }
        else 
        write(fd, "0", 1);
        close(fd);

        return 1;
    }

   int read_gpio(int gpio){
       char array[1];
       char string[10];
        sprintf(string,"%s%d", PATH, gpio);
        int fd = open(string,O_RDWR);

        if(fd < 0){
		printf("\nFailed to open file. %s\n\n", strerror(errno));	//error handling
		return 0; //colocar erro
	    }

        else 
        printf("\n/dev/raspiGpio%d Opened!\n",gpio);//success
       
        read(fd, array, 1);

        printf("O valor do Pin%d= %d.\n", gpio, array[0]-48);

        return array[0]-48;

        close(fd);

        return 1;
    }

