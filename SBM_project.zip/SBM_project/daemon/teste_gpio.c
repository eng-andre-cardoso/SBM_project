#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

#include "gpio_module.h"

int main(){
	write_gpio(20,1);
	read_gpio(20);
	getchar();

	write_gpio(20,0);
	read_gpio(20);
}