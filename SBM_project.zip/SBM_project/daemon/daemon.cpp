#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <sys/time.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <mqueue.h>
#include <sys/msg.h>
#include <iostream>
#include "ctimer.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <ostream>
#include <fstream>

#define DIR "//embedded//msgq.txt"

using namespace std;

#define SIGREED 44
#define MAX_LEN 40
#define PERMS 0644
   

   Timer _timing;
  // Message queue variables  
    key_t key;
    
    int msqid;
    int len;


struct my_msgbuf {
    long mtype;
    char mtext[200];
};
struct my_msgbuf message;


/* Fuctions declaration */

void sig_handler(int n, siginfo_t *info, void *unused);


int main(int argc, char **argv){

    static int reed_sensor;
    struct sigaction act;
    pid_t pid, sid;
    int  fd;
   


    cout << "Daemon starting\n";
    pid = fork(); // new process

    if(pid < 0){

        perror("Fork error");
        exit(EXIT_FAILURE);

    }

    if(pid > 0){

        printf("Daemon with PID: %d\n", pid);
        exit(EXIT_SUCCESS);

    }

    sid = setsid(); // new session is created

    if(sid < 0){

        perror("setsid");
        exit(EXIT_FAILURE);

    }

    if(chdir("/") < 0) { // on error exit

        perror("chdir");
        exit(EXIT_FAILURE);

    }

    umask(0);
   // close(STDIN_FILENO);//  standard input closed
   // close(STDOUT_FILENO);// standard output closed
   // close(STDERR_FILENO);// standard error closed


        pid = getpid();
        printf("PID -> %d\n", pid);
    



    //Message queue code
  
   // system("touch DIR");

       if ((key = ftok(DIR, 'B')) == -1) {
           printf("Erro de key");
            perror("ftok");
        exit(1);
        }


         if ((msqid = msgget(key, PERMS | IPC_CREAT)) == -1) {
             printf("Erro de msqid");
        perror("msgget");
        exit(1);
         }

        cout << "message queue: ready to send messages." << endl;
        
    
    // Signal from device driver

    reed_sensor = open("/dev/Reed_Sensor",O_RDWR);
   
    if(reed_sensor < 0){

        printf("/dev/Reed_Sensor");
        return -1;
    }

    if(ioctl(reed_sensor, 1, &pid)){

        printf("Failed\n");
        close(reed_sensor);
        return -1;
    }
   
        sigemptyset (&act.sa_mask);
        act.sa_flags = SA_SIGINFO;
        act.sa_sigaction = sig_handler;
        sigaction (SIGREED, &act, NULL);

    while(1);

    close(reed_sensor);
    return 1;
}

void sig_handler(int n, siginfo_t *info, void *unused){
    message.mtype = 1;
    double time_passed;
    printf("SIGREED received\n");
    printf("Info received -> %d\n", info -> si_int);
    
    if(_timing.get_flag_timer()){
        _timing.counter_stop();
        time_passed = _timing.counter_get();
    }
    _timing.counter_start();
   //incluir controlo de velocidade minima;
   //time_passed = 1.23;
    //sprintf(message,"%g", time_passed);
    
    sprintf(message.mtext, "%f", time_passed);
    len = strlen(message.mtext);

        //message.mtext[len-1] = '\0';

    cout << message.mtext; 
      //sending message
      if (msgsnd(msqid, &message, len+1, 0) == -1) {
            perror("msgsnd");
    }

}


