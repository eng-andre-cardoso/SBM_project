#include "ctimer.h"
#include "signal.h"


int interrupt_flag = 0;

Timer::Timer(){
    
    this->flag_timer_activated = 0;
}

Timer::~Timer(){


}

void Timer::counter_start(){
    this->flag_timer_activated = 1;
    gettimeofday(&_begin, NULL);
}

void Timer::counter_stop(){

    gettimeofday(&_end, NULL);
}

double Timer::counter_get(){

    double duration = ((_end.tv_sec - _begin.tv_sec) * 1000000 + (_end.tv_usec - _begin.tv_usec));
    counter_reset();
    return duration;
}

void Timer::counter_reset(){

    this->flag_timer_activated = 0;
    _begin.tv_usec = 0;
    _end.tv_usec = 0;
    _begin.tv_sec = 0;
    _end.tv_sec = 0;
}

void Timer::handler_interrupt(int sig){
      interrupt_flag = 1;
    }



void Timer::activateInterrupt(int seconds, int useconds){

    _intervalo.it_interval.tv_sec = seconds;
    _intervalo.it_interval.tv_usec = useconds;
    _intervalo.it_value.tv_sec = seconds;
    _intervalo.it_value.tv_usec = useconds;
    setitimer(ITIMER_REAL, &_intervalo, NULL);
    interrupt_flag = 0;

    signal(SIGALRM, handler_interrupt);
}
    
void Timer::desactivateInterrupt(){

    _intervalo.it_interval.tv_sec = 0;
    _intervalo.it_interval.tv_usec = 0;
    _intervalo.it_value.tv_sec = 0;
    _intervalo.it_value.tv_usec = 0;

    setitimer(ITIMER_REAL, &_intervalo, NULL);

}
  void Timer::set_flag_timer(int n){

      this->flag_timer_activated = n; 

  }
    int Timer::get_flag_timer(){

        return this->flag_timer_activated;

    }


