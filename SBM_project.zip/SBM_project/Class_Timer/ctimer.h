#ifndef CTIMER_H
#define CTIMER_H

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>



using namespace std;

class Timer
{
    struct itimerval _intervalo;
    struct timeval _begin;
    struct timeval _end;
    int flag_timer_activated;
    

public:

    Timer();
    ~Timer();
    void set_flag_timer(int n);
    int get_flag_timer();
    void counter_start();
    void counter_stop();
    double counter_get();
    void counter_reset();
    void activateInterrupt(int seconds, int useconds);
    void desactivateInterrupt();
    static void handler_interrupt(int sig);
};





#endif
    