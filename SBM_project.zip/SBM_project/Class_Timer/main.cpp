#include <iostream>
#include <stdlib.h>
#include "ctimer.h"
#include "unistd.h"


using namespace std;

int main(){

    double tempo;
    Timer _timer;
    _timer.counter_start();
    sleep(5);
    _timer.counter_stop();
    tempo = _timer.counter_get();
    cout << tempo;

};