#include "gpio_module.h"
#include <unistd.h>
#include <iostream>

using namespace std;



int main() {
char leituras[4];

GPIO hardware("/dev/Light_System");
while (1)
{
  hardware.setOutput(21, 1);
 
  hardware.setOutput(21, 0);
  sleep(0.1);
  //usleep(100000);
}

}