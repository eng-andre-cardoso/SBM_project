#include "gpio_module.h"

GPIO::GPIO(const char *patha){
path = patha;
};

void GPIO::setOutput(int gpio, int output){
    char buff[2];

    if(output != 1 && output != 0){
        return;
    }
    gpio+= '0';
    output+= '0';
    buff[0] = gpio;
    buff[1] = output;
    deviceDriver = open(path, O_WRONLY);
    write(deviceDriver, &buff, sizeof(buff));
    close(deviceDriver);
};

void GPIO::getInput(char* leituras){
   
    leituras[0]=-1;
    leituras[1]=-1;
    leituras[2]=-1;
    leituras[3]=-1;

    deviceDriver = open(path, O_RDONLY);
    
    read(deviceDriver, leituras, sizeof(leituras));

    close(deviceDriver);

};

GPIO::~GPIO(){


};




