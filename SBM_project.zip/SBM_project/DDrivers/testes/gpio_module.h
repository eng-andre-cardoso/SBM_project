#ifndef __gpio_module_H__
#define __gpio_module_H__

#include <fcntl.h>
#include <unistd.h>
//#include <QtDebug>
#include <sys/types.h>
#include <sys/stat.h>


class GPIO{
public:

    GPIO(const char* path);
    void setOutput(int gpio, int output);
    void getInput(char* leituras);
    ~GPIO();

private:

    int deviceDriver;
    const char* path;

};


#endif