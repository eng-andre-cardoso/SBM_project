#include <linux/cdev.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/init.h>
#include <asm/io.h>
#include <linux/timer.h>
#include <linux/device.h>
#include <linux/err.h>
#include <linux/mm.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <uapi/asm-generic/errno-base.h>
#include <linux/string.h>
#include <linux/spinlock.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/irq.h>
#include <linux/gpio.h>
#include <linux/init.h>
#include <linux/sched/signal.h>
#include <linux/types.h>


//#include <mach/platform.h>

#include "utils.h"


#define DEVICE_NAME "raspi-gpio"
#define BUF_SIZE 512
#define SIGREED 44
#define SIGINPT 45
#define GPIO_INPUT 0
#define GPIO_OUTPUT 1
#define IOCTL_PID 1


//Pins Names
#define BTURNLEFT 17
#define BTURNRIGHT 27
#define BLIGHTS 22
#define SLIGHT 10
#define REED 9
		
//OUTPUTS

#define TURNLEFT 16
#define TURNRIGHT 20
#define LIGHTS 21


MODULE_LICENSE("GPL");
struct GpioRegisters *s_pGpioRegisters;

/* Forward declaration of functions */
static int raspi_gpio_init(void);
static void raspi_gpio_exit(void);


/* Declaration of entry points */
static int raspi_gpio_open(struct inode* inode, struct file* filp);
static ssize_t raspi_gpio_read(struct file* filp,char* buf, size_t count, loff_t* f_pos);
static ssize_t raspi_gpio_write(struct file* filp, const char* buf,size_t count,loff_t* f_pos);
static int raspi_gpio_release(struct inode* inode, struct file* filp);
static long raspi_gpio_ioctl(struct file* filp, unsigned int cmd, unsigned long arg);
static irqreturn_t irq_handler(int irq, void *dev_id);
static irqreturn_t irq_handler_reed(int irq, void *dev_id);


/* Global varibles for GPIO driver */
static dev_t first;
static struct class* raspi_gpio_class;
static struct cdev c_dev_reed;
static struct cdev c_dev_light_system;


/* File operation structure */
static struct file_operations raspi_gpio_fops = {
.owner = THIS_MODULE,
.open = raspi_gpio_open,
.release = raspi_gpio_release,
.read = raspi_gpio_read,
.write = raspi_gpio_write,
.unlocked_ioctl = raspi_gpio_ioctl,
};

/****************************************************************************/
/* Interrupts variables block                                               */
/****************************************************************************/
static unsigned int irqNumber;
short int irq_any_gpio    = 0;
static int toggle = 1;
static struct kernel_siginfo info;
static pid_t pid;
static struct task_struct *task = NULL;

/***************************************************************/
/* Fuctions                                                    */
/***************************************************************/

ssize_t raspi_gpio_write(struct file *pfile, const char __user *pbuff, size_t len, loff_t *off) { //tirar o static
	struct GpioRegisters *pdev; 

	pr_alert("%s: called (%u)\n",__FUNCTION__,len);

	if(unlikely(pfile->private_data == NULL))
		return -EFAULT;

	pdev = (struct GpioRegisters *)pfile->private_data;

	if((pbuff[0]-'0')!= TURNLEFT && (pbuff[0]-'0')!= TURNRIGHT && (pbuff[0]-'0')!= LIGHTS) return 0;

	SetGPIOOutputValue(s_pGpioRegisters, (pbuff[0]-'0'), (pbuff[1]-'0'));

	pr_alert("GPIO: %d com valor = %d \n ",(pbuff[0]-'0'), (pbuff[1]-'0'));

	return 0;

}

ssize_t raspi_gpio_read(struct file *pfile, char __user *p_buff,size_t len, loff_t *poffset){
	struct GpioRegisters *pdev; 
	int minor;

	if(unlikely(pfile->private_data == NULL))
		return -EFAULT;

	pdev = (struct GpioRegisters *)pfile->private_data;

	minor = iminor(pfile->f_path.dentry->d_inode);

	if(minor == 1){

		p_buff[0] = (ReadGPIOFunction(pdev, REED)+48);

	}
	
	else{
	
	//read pins
	p_buff[0] = (ReadGPIOFunction(pdev, TURNLEFT)+48);
	p_buff[1] = (ReadGPIOFunction(pdev, TURNRIGHT)+48);
	p_buff[2] = (ReadGPIOFunction(pdev, LIGHTS)+48);
	p_buff[3] = (ReadGPIOFunction(pdev, SLIGHT)+48);
	}
	return 0;
}

int raspi_gpio_release(struct inode *p_inode, struct file * pfile){
	
	pr_alert("%s: called\n",__FUNCTION__);
	pfile->private_data = NULL;
	return 0;
}

int raspi_gpio_open(struct inode* p_indode, struct file *p_file){
	
	pr_alert("%s: called\n",__FUNCTION__);
	p_file->private_data = (struct GpioRegisters *) s_pGpioRegisters;
	return 0;
	
}

static int __init raspi_gpio_init(void) {
	int ret;
	struct device *dev_ret;
	int i;
	int index = 0;

	s_pGpioRegisters = (struct GpioRegisters *)ioremap(GPIO_BASE, sizeof(struct GpioRegisters));
	

	pr_alert("map to virtual adresse: 0x%x\n", (unsigned)s_pGpioRegisters);
	pr_alert("%s: called\n",__FUNCTION__);

	
	if ((ret = alloc_chrdev_region(&first, 0, 2, DEVICE_NAME)) < 0) {
		return ret;
	}
	
	if (IS_ERR(raspi_gpio_class = class_create(THIS_MODULE, DEVICE_NAME))) {
		unregister_chrdev_region(first, 2);
	}

	if (device_create(raspi_gpio_class,NULL, MKDEV(MAJOR(first), MINOR(first)+1), NULL, "Reed_Sensor",1) == NULL) {
			class_destroy(raspi_gpio_class);
			unregister_chrdev_region(first, 2);
			return -1;
		}

	if (device_create(raspi_gpio_class,NULL, MKDEV(MAJOR(first), MINOR(first) + 2), NULL, "Light_System",2) == NULL) {
			class_destroy(raspi_gpio_class);
			unregister_chrdev_region(first, 2);
			return -1;
		}

	cdev_init(&c_dev_reed, &raspi_gpio_fops);
	c_dev_reed.owner = THIS_MODULE;

	if((ret=cdev_add(&c_dev_reed, (first+1), 1)) < 0){

		printk(KERN_NOTICE "ERROR %d adding device", ret);
		device_destroy(raspi_gpio_class, MKDEV(MAJOR(first), MINOR(first) + 1));
		class_destroy(raspi_gpio_class);
		unregister_chrdev_region(first, 2);
		return ret;
	}

	cdev_init(&c_dev_light_system, &raspi_gpio_fops);
	c_dev_reed.owner = THIS_MODULE;

	if((ret=cdev_add(&c_dev_reed, (first+2), 1)) < 0){

		printk(KERN_NOTICE "ERROR %d adding device", ret);
		device_destroy(raspi_gpio_class, MKDEV(MAJOR(first), MINOR(first) + 2));
		class_destroy(raspi_gpio_class);
		unregister_chrdev_region(first, 2);
		return ret;
	}

	//define Pins Fuction
	//iNPUTS

	SetGPIOFunction(s_pGpioRegisters, BTURNLEFT, GPIO_INPUT);
	SetGPIOFunction(s_pGpioRegisters, BTURNRIGHT, GPIO_INPUT);
	SetGPIOFunction(s_pGpioRegisters, BLIGHTS, GPIO_INPUT);
	SetGPIOFunction(s_pGpioRegisters, SLIGHT, GPIO_INPUT);
	SetGPIOFunction(s_pGpioRegisters, REED, GPIO_INPUT);
		
	//OUTPUTS

	SetGPIOFunction(s_pGpioRegisters, TURNLEFT, GPIO_OUTPUT);
	SetGPIOFunction(s_pGpioRegisters, TURNRIGHT, GPIO_OUTPUT);
	SetGPIOFunction(s_pGpioRegisters, LIGHTS, GPIO_OUTPUT);


	//Interrupts

	if(request_irq(gpio_to_irq(BTURNLEFT), irq_handler, IRQF_TRIGGER_RISING, DEVICE_NAME, (void*)(irq_handler))) ret=1;
	if(request_irq(gpio_to_irq(BTURNRIGHT), irq_handler, IRQF_TRIGGER_RISING, DEVICE_NAME, (void*)(irq_handler))) ret=1;
	if(request_irq(gpio_to_irq(BLIGHTS), irq_handler, IRQF_TRIGGER_RISING, DEVICE_NAME, (void*)(irq_handler))) ret=1;
	if(request_irq(gpio_to_irq(SLIGHT), irq_handler, IRQF_TRIGGER_RISING, DEVICE_NAME, (void*)(irq_handler))) ret=1;
	if(request_irq(gpio_to_irq(REED), irq_handler_reed, IRQF_TRIGGER_RISING, DEVICE_NAME, (void*)(irq_handler_reed))) ret=1;

	
	

	if(ret == 1){

			printk(KERN_INFO "Cannot register IRQ\n");
			 free_irq(gpio_to_irq(BTURNLEFT),(void *)(irq_handler));
			 free_irq(gpio_to_irq(BTURNRIGHT),(void *)(irq_handler));
			 free_irq(gpio_to_irq(BLIGHTS),(void *)(irq_handler));
			 free_irq(gpio_to_irq(SLIGHT),(void *)(irq_handler));
			 free_irq(gpio_to_irq(REED),(void *)(irq_handler_reed));
			class_destroy(raspi_gpio_class);
			unregister_chrdev_region(first, 2);
	}

	return 0;
}

static long raspi_gpio_ioctl(struct file* filp, unsigned int cmd, unsigned long arg){
		if(cmd == IOCTL_PID){
			
			if(copy_from_user(&pid, (pid_t*)arg, sizeof(pid_t)))
			{
				printk(KERN_INFO "copy_from_user failed\n");
				return -1;
			}

			printk(KERN_INFO "PID->%d\n", pid);
		}
		else{
			printk(KERN_INFO "ioctl failed\n");
		}
		return 0;
}

static void __exit raspi_gpio_exit(void) {
	int i;
	int index = 0;
	pr_alert("%s: called\n",__FUNCTION__);

		device_destroy(raspi_gpio_class,MKDEV(MAJOR(first), MINOR(first) + i));
		cdev_del(&c_dev_reed);
		cdev_del(&c_dev_light_system);
		iounmap(s_pGpioRegisters);
		free_irq(gpio_to_irq(BTURNLEFT),(void *)(irq_handler));
		free_irq(gpio_to_irq(BTURNRIGHT),(void *)(irq_handler));
		free_irq(gpio_to_irq(BLIGHTS),(void *)(irq_handler));
		free_irq(gpio_to_irq(SLIGHT),(void *)(irq_handler));
		free_irq(gpio_to_irq(REED),(void *)(irq_handler_reed));
		class_destroy(raspi_gpio_class);
		unregister_chrdev_region(first, 2);
		iounmap(s_pGpioRegisters);
		printk(KERN_INFO,"RaspberryPi GPIO driver removed\n");
}


/****************************************************************************/
/* IRQ handler REED - fired on interrupt                                         */
/***************************************************************************/
static irqreturn_t irq_handler_reed(int irq, void *dev_id) {
   unsigned long flags;
   volatile unsigned int val;
   int value;

   printk(KERN_NOTICE "Interrupt [%d] for device %s was triggered !.\n", irq, (char *) dev_id);

	if(value=ReadGPIOFunction(s_pGpioRegisters, REED)){
	pr_alert("Value from gpio%d = %d",irq, value);
	}
 	
	info.si_signo = SIGREED;
	info.si_code = SI_QUEUE;
	info.si_int = toggle;
	printk(KERN_INFO "Pin -> %d\n", value);

	task = pid_task(find_pid_ns(pid, &init_pid_ns), PIDTYPE_PID);

	if(task != NULL){

		if(send_sig_info(SIGREED, &info, task) < 0){
			printk(KERN_INFO "Signal not sent\n");
		}
		else{
			printk(KERN_INFO "Signal sent\n");
		}
	}
	return IRQ_HANDLED;
}

/****************************************************************************/
/* IRQ handler  - fired on interrupt                                         */
/***************************************************************************/
static irqreturn_t irq_handler(int irq, void *dev_id) {
   
   unsigned long flags;
   volatile unsigned int val;
   int value;

  	pr_alert("Value from gpio%d = %d",irq, value);

	info.si_signo = SIGINPT;
	info.si_code = SI_QUEUE;
	info.si_int = toggle;
	printk(KERN_INFO "Pin -> %d\n", value);

	task = pid_task(find_pid_ns(pid, &init_pid_ns), PIDTYPE_PID);

	if(task != NULL){

		if(send_sig_info(SIGINPT, &info, task) < 0){
			printk(KERN_INFO "Signal not sent\n");
		}

		else{
			printk(KERN_INFO "Signal sent\n");
		}
	}
	return IRQ_HANDLED;
}

module_init(raspi_gpio_init);
module_exit(raspi_gpio_exit);
